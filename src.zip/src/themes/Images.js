// leave off @2x/@3x
const images = {
  Alert: require('../images/Alert.png'),
  
}

export default images
